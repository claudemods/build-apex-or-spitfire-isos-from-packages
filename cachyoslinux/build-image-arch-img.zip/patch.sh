#!/bin/bash

# Function to detect the distribution
detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DISTRO=$ID
    else
        echo "Cannot detect the distribution. Exiting."
        exit 1
    fi
}

# Main script starts here
cd /home/$USER >/dev/null 2>&1

# Detect the distribution
detect_distro

# Conditional logic based on the detected distribution
if [[ "$DISTRO" == "arch" || "$DISTRO" == "cachyos" ]]; then
    # Commands for Arch/CachyOS
    git clone https://github.com/claudemods/claudemods-distribution-iso-creator-Beta.git  >/dev/null 2>&1
    cd /home/$USER/claudemods-distribution-iso-creator-Beta/cachyos/updater && g++ -std=c++23 main.cpp -o updater.bin >/dev/null 2>&1
    ./updater.bin && rm -rf /home/$USER/claudemods-distribution-iso-creator-Beta
else
    echo "Unsupported distribution: $DISTRO"
    exit 1
fi
